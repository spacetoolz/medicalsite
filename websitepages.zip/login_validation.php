<?php
	
	$errors = array();
	if (isset($_POST['btn_submit'])){
		//sql connection
		$con = mysqli_connect("localhost", "root", "", "medical");
		$sql = "SELECT * FROM users WHERE userName='" . $_POST["username"] . "' and password = '". $_POST["password"]."'";
		
		if (mysqli_error($con)){ // checking if connection is active
			
			die("something went wrong");
			
		}else{
			
			if((!empty($_POST["username"])) && (!empty($_POST["password"]))) {
				
				$result = mysqli_query($con,$sql);
				
				while(!($_POST['username'] == $row[3]) && (md5($_POST['password']) == $row[4])){
					
					$row  = mysqli_fetch_array($result);
				}
					
				if(is_array($row)) {
					$_SESSION["Username"] = $row['userName'];
					$_SESSION["fname"] = $row['fname'];
					$_SESSION["lname"] =  $row['lname'];
					$_SESSION["email"] =  $row['email'];
					$_SESSION["userType"] =  $row['userType'];
					$_SESSION["staffId"] = $row['staffId'];
					$_SESSION["userpassword"] = $row['password'];
					
					print_r ($_SESSION);
				}
			} else {
				$errors['login']= "Invalid Username or Password!";
			}
				
		}
	}
?>