<html>
	<head>
		
	</head>
	
	<body>
	
		<?php
			session_start();
			$_SESSION['useroffset'] = 0;
			include "user_validate.php";
			
			echo "
				<form  height=100% action='' method='POST' class='form-horizontal'>
					<fieldset style='padding:50px;'>
						
						<div class='form-group'>
							<div class='col-md-5 col-xs-5'>
								First name:<input class='form-control input-lg' type='text' name='fname' placeholder='Jane' value='' title='Please enter firstname'>
								<span class='error'>"; if (isset($errors['fname1'])) ECHO $errors['fname1']; echo "</span>
							</div>
							<div class='col-md-5 col-xs-5'>
								Last name: <input class='form-control input-lg' type='text' name='lname' placeholder='Doe' value='' title='Please Enter Lastname' >
								<span class='error'>"; if (isset($errors['lname1'])) ECHO $errors['lname1']; echo "</span>
								
							</div>
							
						</div>
						
						<div class='form-group'>
							<div class='col-md-5 col-xs-5'>
								Email:<input class='form-control input-lg' type='email' name='usrEmail' placeholder='someone@domain.com' value='' title='User email address goes here'>
								<span class='error'>"; if (isset($errors['email1'])) ECHO $errors['email1']; echo "</span>
							</div>
							
							<div class='col-md-5 col-xs-5'>
								staff ID:<input class='form-control input-lg' type='number' name='staffId' placeholder='5014' value='' title='Staff ID address goes here'>
								
							</div>
						</div>
						
						<div class='form-group'>
							<div class='col-md-5 col-xs-5'>
								User Name:<input class='form-control input-lg' type='text' name='usrname' placeholder='jdoe' value='' title='E.g. John Smith -> jsmith'>
								<span class='error'>"; if (isset($errors['usrname'])) ECHO $errors['usrname']; echo "</span>
							</div>
							<div class='col-md-5 col-xs-5'>
								Password:<input class='form-control input-lg' type='text' name='pswrd' placeholder='Jane' value='"; echo 'Default1@3'; echo"' title='default password for each user' readonly>
								
							</div>
						</div>
						
						<div class='form-group'>
							<div class='col-md-2 col-xs-4'>
								type<select name = 'type' class='form-control input-lg'>
										<option value = 'Doctor'>Doctor</option>
										<option value = 'Nurse'>Nurse</option>
										<option value = 'Administrator'>Administrator</option>
									</select>
							</div>
							<div class='col-md-2 col-xs-4'>
							</div>
						</div>
						
						<div class='form-group'>
							<div class='col-lg-5'>
								<button name='btn_submit' class='btn btn-success' type='submit'> Submit </button>
								</br></br>
							</div>
						</div>
					</fieldset>
				</form>
				
				
			";
		?>
		
		
	</body>
	
	<link href="Css/bootstrap.min.css" rel="stylesheet" />
	<style>
		.btn-md{
			width:135px;
		}
	</style>

</html>
